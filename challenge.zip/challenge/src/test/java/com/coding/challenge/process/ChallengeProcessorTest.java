package com.coding.challenge.process;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.jupiter.api.Assertions.*;

import com.coding.challenge.model.Challenge;

public class ChallengeProcessorTest {
	@Autowired
	ChallengeProcessor processor;

	/*
	 * @BeforeEach public void setup() { processor = new ChallengeProcessor(); }
	 */

	@Test
	public void isProcessing_returns_true_ifallpassed() {
		List<Challenge> cL = new ArrayList<>();
		Challenge c1 = new Challenge("q1", "a1", true);
		Challenge c2 = new Challenge("q2", "a2", true);
		Challenge c3 = new Challenge("q3", "a1", true);
		Challenge c4 = new Challenge("q4", "a2", true);
		Challenge c5 = new Challenge("q5", "a2", true);
		Challenge c6 = new Challenge("q6", "a2", true);
		cL.add(c1);
		cL.add(c2);
		cL.add(c3);
		cL.add(c4);
		cL.add(c5);
		cL.add(c6);

		boolean result = processor.isPassing(cL);
		assertTrue(result);
	}

	@Test
	public void testIsProcessing_returns_true_if_greaterthan_87_5() {
		List<Challenge> cc = new ArrayList<>();
		Challenge c1 = new Challenge("q1", "a1", false);
		Challenge c2 = new Challenge("q2", "a2", true);
		Challenge c3 = new Challenge("q3", "a1", true);
		Challenge c4 = new Challenge("q4", "a2", true);
		Challenge c5 = new Challenge("q5", "a2", true);
		Challenge c6 = new Challenge("q6", "a1", true);
		Challenge c7 = new Challenge("q7", "a2", true);
		Challenge c8 = new Challenge("q8", "a1", true);
		Challenge c9 = new Challenge("q9", "a1", true);
		cc.add(c1);
		cc.add(c2);
		cc.add(c3);
		cc.add(c4);
		cc.add(c5);
		cc.add(c6);
		cc.add(c7);
		cc.add(c8);
		cc.add(c9);
		boolean result = processor.isPassing(cc);
		assertTrue(result);
	}

	@Test
	public void testIsProcessing_returns_false_if_lessthan_87_5() {
		List<Challenge> cc = new ArrayList<>();
		Challenge c1 = new Challenge("q1", "a1", true);
		Challenge c2 = new Challenge("q2", "a2", true);
		Challenge c3 = new Challenge("q3", "a1", true);
		Challenge c4 = new Challenge("q4", "a2", true);
		Challenge c5 = new Challenge("q5", "a2", false);
		cc.add(c1);
		cc.add(c2);
		cc.add(c3);
		cc.add(c4);
		cc.add(c5);
		boolean result = processor.isPassing(cc);
		assertFalse(result);
	}

	@Test
	public void testIsProcessing_returns_false_if_equal_to_87_5() {
		List<Challenge> cc = new ArrayList<>();
		Challenge c1 = new Challenge("q1", "a1", false);
		Challenge c2 = new Challenge("q2", "a2", true);
		Challenge c3 = new Challenge("q3", "a1", true);
		Challenge c4 = new Challenge("q4", "a2", true);
		Challenge c5 = new Challenge("q5", "a2", true);
		Challenge c6 = new Challenge("q6", "a1", true);
		Challenge c7 = new Challenge("q7", "a2", true);
		Challenge c8 = new Challenge("q8", "a1", true);
		cc.add(c1);
		cc.add(c2);
		cc.add(c3);
		cc.add(c4);
		cc.add(c5);
		cc.add(c6);
		cc.add(c7);
		cc.add(c8);
		boolean result = processor.isPassing(cc);
		assertFalse(result);
	}

}
