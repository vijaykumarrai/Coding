package com.coding.challenge.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Component;
import com.coding.challenge.model.Challenge;

@Component
public class ChallengeDao {

	/**
	 * Returns List<Challenge> from DB. In this case test data objects from the
	 * challengesMap.
	 * 
	 * @param id
	 * @return List<Challenge>
	 */
	public List<Challenge> getChallenges(String id) {
		return challengesMap.get(id);
	}

	static Map<String, List<Challenge>> challengesMap = new HashMap<>();
	static {
		List<Challenge> l1 = new ArrayList<>();
		Challenge c1 = new Challenge("q1", "a1", false);
		Challenge c2 = new Challenge("q2", "a2", true);
		Challenge c3 = new Challenge("q3", "a1", true);
		Challenge c4 = new Challenge("q4", "a2", true);
		Challenge c5 = new Challenge("q5", "a2", true);
		l1.add(c1);
		l1.add(c2);
		l1.add(c3);
		l1.add(c4);
		l1.add(c5);
		challengesMap.put("1", l1);
		List<Challenge> l2 = new ArrayList<>();
		Challenge c21 = new Challenge("q1", "a1", false);
		Challenge c22 = new Challenge("q2", "a2", true);
		Challenge c23 = new Challenge("q3", "a1", true);
		Challenge c24 = new Challenge("q4", "a2", true);
		Challenge c25 = new Challenge("q5", "a2", true);
		l2.add(c21);
		l2.add(c22);
		l2.add(c23);
		l2.add(c24);
		l2.add(c25);
		challengesMap.put("2", l2);
		List<Challenge> l3 = new ArrayList<>();
		challengesMap.put("3", null);
	}
}