package com.coding.challenge.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.coding.challenge.model.Challenge;
import com.coding.challenge.service.ChallengeService;

@RestController
public class ChallengeController {
	@Autowired
	ChallengeService service;
	
	/**
	 * 1) Accepts interviewId as input in Path Variable.
	 * 2) Calls Service class and get the List of Challenge objects.
	 * 3) Return the response as JSON containing array of Challenge objects.
	 * 4) Return null otherwise.
	 * 
	 * @param id
	 * @return ResponseEntity<List<Challenge>>
	 */
	@GetMapping(path = "/interviews/{interviewId}")
	public ResponseEntity<List<Challenge>> getInterview(@PathVariable("interviewId") String id) {
		List<Challenge> challenges = null;
		try {
			challenges = service.getChallenges(id);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		}
		
		return ResponseEntity.ok().body(challenges);
	}
}