package com.coding.challenge.process;

import java.util.List;

import com.coding.challenge.model.Challenge;

public class ChallengeProcessor {
	/**
	 * 1) This method accepts a collection of Challenge objects s the input. 
	 * 2) Process challenges list using Java 8 streams and get the count of objects with correct as true. 
	 * 3) Calculate the percentage.
	 * 4) Return true if percentage is greater than 87.5, if not false.
	 * 
	 * @param challenges
	 * @return boolean
	 */
	public static boolean isPassing(List<Challenge> challenges) {
		long passCount = challenges.stream().filter(e -> e.isCorrect() == true).count();

		if (((passCount * 100) / challenges.size()) > 87.5) {
			return true;
		}
		
		return false;
	}
}