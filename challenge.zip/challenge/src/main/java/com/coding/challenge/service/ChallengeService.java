package com.coding.challenge.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coding.challenge.dao.ChallengeDao;
import com.coding.challenge.model.Challenge;

@Service
public class ChallengeService {
	@Autowired
	ChallengeDao dao;

	/**
	 * Get challenges from DAO.
	 * 
	 * @param id
	 * @return List<Challenge>
	 */
	public List<Challenge> getChallenges(String id) {
		try {
			return dao.getChallenges(id);
		} catch (Exception e) {
			System.out.println("Exception " + e);
			throw e;
		}
	}

}
