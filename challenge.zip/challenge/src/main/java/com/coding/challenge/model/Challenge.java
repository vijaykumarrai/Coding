package com.coding.challenge.model;

public class Challenge {
	/**
	 * The question that will be asked.
	 */
	private String question;
	/**
	 * The answer to the challenge question.
	 */
	private String answer;
	/**
	 * A boolean that indicates whether the provided answer is correct.
	 */
	private boolean correct;

	public Challenge(String question, String answer, boolean correct) {
		super();
		this.question = question;
		this.answer = answer;
		this.correct = correct;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public boolean isCorrect() {
		return correct;
	}

	public void setCorrect(boolean correct) {
		this.correct = correct;
	}
}